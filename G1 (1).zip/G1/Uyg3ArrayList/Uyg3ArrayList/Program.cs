﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Uyg3ArrayList
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList dinamikDizi = new ArrayList();
            dinamikDizi.Add("ali");
            dinamikDizi.Add(1);
            dinamikDizi.Add(3.2);
            dinamikDizi.Add(true);
            Kitap k = new Kitap();
            dinamikDizi.Add(k);

            //dinamikDizi.Sort();

            //kapasite nasıl değişiyor
            ArrayList dinamikDizi2 = new ArrayList();
            int sayi;
            do
            {
                sayi = Convert.ToInt32(Console.ReadLine());
                dinamikDizi2.Add(sayi);
                Console.WriteLine("Count:{0}", dinamikDizi2.Count);
                Console.WriteLine("Capacity:{0}", dinamikDizi2.Capacity);

            } while (sayi != -1);

            dinamikDizi2.Sort();

            //  dinamikDizi2.Capacity = 5;
            for (int i = 0; i < dinamikDizi2.Count; i++)
                Console.WriteLine(dinamikDizi2[i]);

            // foreach (int i in dinamikDizi)
            //    Console.WriteLine(i);

            dinamikDizi2.Insert(1, 120);
            Console.WriteLine("Insert Sonrasi");
            for (int i = 0; i < dinamikDizi2.Count; i++)
                Console.WriteLine(dinamikDizi2[i]);

            dinamikDizi2.Remove(120);
            Console.WriteLine("Remove Sonrasi");
            for (int i = 0; i < dinamikDizi2.Count; i++)
                Console.WriteLine(dinamikDizi2[i]);

            int indis = dinamikDizi2.IndexOf(5);
            int sonindis = dinamikDizi2.LastIndexOf(5);
            int bsIndis = dinamikDizi2.BinarySearch(5);//dizinin sirali olmasi gerekir

            dinamikDizi2.AddRange(dinamikDizi);



        }
    }//class
    class Kitap
    {
        public string kitapAdi;
    }
}//namespace
