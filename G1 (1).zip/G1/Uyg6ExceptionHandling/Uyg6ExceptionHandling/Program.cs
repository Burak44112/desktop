﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uyg6ExceptionHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int a = Convert.ToInt32(Console.ReadLine());
                int b = Convert.ToInt32(Console.ReadLine());
                int c = a / b;
                Console.WriteLine(c);
            }
            catch (FormatException e)
            {
                Console.WriteLine("Lutfen Sayı Değeri Giriniz");
            }

            catch (DivideByZeroException e)
            {
                Console.WriteLine("Bölen 0 olamaz");
            }

            catch
            {
                Console.WriteLine("Hata olustu");
            }
            finally
            {
                Console.WriteLine("hem try hem catch durumunda calisir");
            }
        }
    }
}
