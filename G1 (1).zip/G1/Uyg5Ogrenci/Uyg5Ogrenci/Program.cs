﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uyg5Ogrenci
{
    class Program
    {
        static void Main(string[] args)
        {
            Ogrenci o1 = new Ogrenci();
            o1.adi = "Ali";
            o1.soyadi = "Akay";
            o1.numara = 5000;
            o1.DersEkle("Matematik");
            o1.DersEkle("Fizik");
            o1.DersEkle("Programlama");
            o1.DersEkle("Kimya");

           // o1.notGir("Programlama", 40, 50);

            Ogrenci o2 = new Ogrenci();
            o2.DersEkle("Programlama");
        }
    }
}
