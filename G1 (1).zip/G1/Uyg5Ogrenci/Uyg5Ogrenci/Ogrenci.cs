﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uyg5Ogrenci
{
    class Ogrenci
    {
        public string adi;
        public string soyadi;
        public int numara;

        List<Ders> aldigiDersler = new List<Ders>();

        public void DersEkle(string dersAdi)
        {
            Ders d = new Ders();
            d.Adi = dersAdi;
            aldigiDersler.Add(d);
        }

        public void notGir(string dersAdi, int v, int f)
        {

        }

        public double ganoHEsabı()
        {
            return 0;
        }
    }
}
