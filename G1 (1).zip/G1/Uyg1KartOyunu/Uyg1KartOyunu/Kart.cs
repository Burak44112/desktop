﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uyg1KartOyunu
{
    class Kart
    {

        public string turu;
        public string sayisi;
        public int puani;

        public void bilgiYaz()
        {
            Console.WriteLine("{0}-{1}:puan:{2}", turu, sayisi, puani);
        }
    }
}
