﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uyg1KartOyunu
{
    class Oyun
    {
        Deste destemiz = new Deste();
        int o1P = 0;
        int o2P = 0;

        public void baslat()
        {
            destemiz.olustur();
            destemiz.karistir();
        }

        public void oyna()
        {
            Kart o1k1 = destemiz.kartCek();
            Kart o1k2 = destemiz.kartCek();

            Kart o2k1 = destemiz.kartCek();
            Kart o2k2 = destemiz.kartCek();

            Console.WriteLine("Oyuncu1 Eli");
            o1k1.bilgiYaz();
            o1k2.bilgiYaz();
            o1P = o1k1.puani + o1k2.puani;
            Console.WriteLine("Oyuncu1 Puan:{0}", o1P);

            Console.WriteLine("\nOyuncu2 Eli");
            o2k1.bilgiYaz();
            o2k2.bilgiYaz();
            o2P = o2k1.puani + o2k2.puani;
            Console.WriteLine("Oyuncu2 Puan:{0}", o2P);

            Console.WriteLine("Sonuc:");
            if (o1P > o2P)
                Console.WriteLine("oyuncu 1 kazandi");
            else if (o2P > o1P)
                Console.WriteLine("Oyuncu 2 kazandi");
            else
                Console.WriteLine("Puanlar eşit");

        }


    }
}
