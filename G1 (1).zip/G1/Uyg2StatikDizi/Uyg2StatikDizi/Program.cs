﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uyg2StatikDizi
{
    class Program
    {
        static void Main(string[] args)
        {
            //tur[] dizi=new tur[M]
            string[] ogrenciler = new string[] { "Ali", "Ahmet", "Ayse", "Fatma", "Ali" };

            string aranan = "Fatma";

            for (int i = 0; i < ogrenciler.Length; i++)
            {
                if(ogrenciler[i]==aranan)
                    Console.WriteLine("Bulundu");
            }

        
            foreach (string isim in ogrenciler)
            {
                if (isim == aranan)
                    Console.WriteLine("Bulundu");
            }

            int indis = Array.IndexOf(ogrenciler, "Ali");
            Console.WriteLine("IndexOf ile {0}.indiste bulundu", indis);

            int indis2 = Array.LastIndexOf(ogrenciler, "Ali");
            Console.WriteLine("LastIndexOf ile {0}.indiste bulundu", indis2);

            Array.Sort(ogrenciler);
            foreach (string a in ogrenciler)
                Console.WriteLine(a);

            int bsIndis = Array.BinarySearch(ogrenciler, "Ali");
            Console.WriteLine("BinarySearch ile {0}.indiste bulundu", bsIndis);

            Array.Reverse(ogrenciler);
            Console.WriteLine("Tersten sıralanmış hali");

            foreach (string a in ogrenciler)
                Console.WriteLine(a);


            int boyut = Convert.ToInt32(Console.ReadLine());
            string[] dizi = new string[boyut];



        }
    }
}
