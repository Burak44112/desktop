﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uyg4ListYapisi
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> liste = new List<string>();
            liste.Add("ali");
            liste.Add("ayse");
            liste.Add("ahmet");
            liste.Add("Mehmet");

            /* List<string> sonuclar = new List<string>();
             for (int i = 0; i < liste.Count; i++)
             {
                 if (liste[i].StartsWith("a") == true)
                     sonuclar.Add(liste[i]);
             }*/

            List<string> sonuclar = liste.FindAll(x => x.StartsWith("a") == true);
            foreach (string a in sonuclar)
                Console.WriteLine(a);
            liste.RemoveAll(y => y.Contains("met") == true);
            Console.WriteLine("Remove Sonrasi");
            foreach (string a in liste)
                Console.WriteLine(a);

        }
    }
}
